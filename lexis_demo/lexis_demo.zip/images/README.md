# Image sources

Blue ridge mountain photos from [wallpaperaccess.com](https://wallpaperaccess.com/blue-ridge-mountains)

https://wallpaperaccess.com/download/blue-ridge-mountains-475339
